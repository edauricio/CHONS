#include <stdio.h>

int main()
{
    printf( "ok\n" );
    return 0;
}
